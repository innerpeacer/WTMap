import './build/benchmarks/versions/chunk1';
import './build/benchmarks/versions/worker';
import './build/benchmarks/versions/benchmarks';
