ipmap.js中的
    import './build/ipmap/index';
    文件名index不能换成其他文件
