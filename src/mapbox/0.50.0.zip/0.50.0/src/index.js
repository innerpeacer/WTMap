import exported from "./ip_index_2.4.0";
export default exported;