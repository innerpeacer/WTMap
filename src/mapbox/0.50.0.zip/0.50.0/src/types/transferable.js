// @flow

export type Transferable = ArrayBuffer | MessagePort | ImageBitmap;
