// @flow

export type Cancelable = { cancel: () => void };
