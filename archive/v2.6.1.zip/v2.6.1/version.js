// @flow
export let version: string = 'v2.6.1';
export let useMapboxVersion: string = '1.0.0';
