export var version = "2.5.0";
